There's a better importer built-in at Theme Settings > Sample Import. That importer will import widgets, setup random images, and setup menu. 
